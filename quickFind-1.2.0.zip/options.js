// 配置页面逻辑
document.addEventListener('DOMContentLoaded', () => {
  // 模拟chrome.storage API用于预览
  if (typeof chrome === 'undefined' || !chrome.storage) {
    window.chrome = {
      storage: {
        sync: {
          get: (keys) => Promise.resolve({ urls: ['https://github.com', 'https://stackoverflow.com', 'https://developer.mozilla.org'] }),
          set: (data) => Promise.resolve()
        }
      },
      runtime: {
        sendMessage: (message) => Promise.resolve({ success: true })
      }
    };
  }
  const urlInput = document.getElementById('urlInput');
  const addBtn = document.getElementById('addBtn');
  const urlList = document.getElementById('urlList');
  const urlCount = document.getElementById('urlCount');
  const emptyState = document.getElementById('emptyState');
  const inputError = document.getElementById('inputError');
  const inputSuccess = document.getElementById('inputSuccess');
  const openAllBtn = document.getElementById('openAllBtn');
  const clearAllBtn = document.getElementById('clearAllBtn');
  const themeSelect = document.getElementById('themeSelect');

  let urls = [];
  let themeManager;

  // 初始化加载数据
  loadUrls();
  
  // 初始化主题管理器
  initThemeManager();

  // 动态设置版本号
  try {
    const manifestData = chrome.runtime.getManifest();
    const versionElement = document.querySelector('.footer-card div:first-child div:last-child');
    if (versionElement) {
      versionElement.textContent = `Version ${manifestData.version}`;
    }
  } catch (error) {
    console.error('Failed to set version:', error);
  }

  // 添加按钮事件
  addBtn.addEventListener('click', addUrl);
  
  // 回车键添加
  urlInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      addUrl();
    }
  });

  // 打开所有URL按钮事件
  openAllBtn.addEventListener('click', async () => {
    if (urls.length === 0) {
      showError('No URLs to open');
      return;
    }
    
    openAllBtn.disabled = true;
    const buttonText = openAllBtn.querySelector('span:not(.button-icon)');
    const originalText = buttonText ? buttonText.textContent : 'Open All';
    if (buttonText) buttonText.textContent = 'Opening...';
    
    try {
      await chrome.runtime.sendMessage({ action: 'openAllUrls' });
      showSuccess('All URLs opened successfully');
    } catch (error) {
      showError('Failed to open: ' + error.message);
    } finally {
      openAllBtn.disabled = false;
      if (buttonText) buttonText.textContent = originalText;
    }
  });

  // 清空所有按钮事件
  clearAllBtn.addEventListener('click', () => {
    if (urls.length === 0) {
      showError('No URLs to clear');
      return;
    }
    
    if (confirm('Are you sure you want to clear all URLs? This action cannot be undone.')) {
      urls = [];
      saveUrls();
      renderUrlList();
      showSuccess('All URLs cleared');
    }
  });

  // 从存储加载 URL 列表
  async function loadUrls() {
    try {
      const result = await chrome.storage.sync.get(['urls']);
      urls = result.urls || [];
      renderUrlList();
    } catch (error) {
      console.error('Failed to load data:', error);
      showError('Failed to load data');
    }
  }

  // 保存 URL 列表到存储
  async function saveUrls() {
    try {
      await chrome.storage.sync.set({ urls: urls });
    } catch (error) {
      console.error('Failed to save data:', error);
      showError('Failed to save data');
    }
  }

  // 验证和规范化 URL
  function validateAndNormalizeUrl(input) {
    if (!input || !input.trim()) {
      throw new Error('Please enter a URL');
    }

    let url = input.trim();
    
    // 自动补全协议前缀
    if (!url.match(/^https?:\/\//i)) {
      url = 'https://' + url;
    }

    // 验证 URL 格式
    try {
      const urlObj = new URL(url);
      
      // 检查协议
      if (!['http:', 'https:'].includes(urlObj.protocol)) {
        throw new Error('Only HTTP and HTTPS protocols are supported');
      }
      
      // 检查主机名
      if (!urlObj.hostname) {
        throw new Error('Invalid URL format');
      }
      
      return urlObj.href;
    } catch (e) {
      if (e.message.includes('Invalid URL')) {
        throw new Error('Invalid URL format');
      }
      throw e;
    }
  }

  // 添加 URL
  async function addUrl() {
    hideMessages();
    
    try {
      const normalizedUrl = validateAndNormalizeUrl(urlInput.value);
      
      // 检查是否已存在
      if (urls.includes(normalizedUrl)) {
        throw new Error('This URL already exists');
      }
      
      // 添加到列表
      urls.push(normalizedUrl);
      await saveUrls();
      
      // 更新界面
      renderUrlList();
      urlInput.value = '';
      showSuccess('URL added successfully');
      
    } catch (error) {
      showError(error.message);
    }
  }

  // 删除 URL
  async function removeUrl(index) {
    if (index >= 0 && index < urls.length) {
      urls.splice(index, 1);
      await saveUrls();
      renderUrlList();
      showSuccess('URL removed successfully');
    }
  }

  // 渲染 URL 列表
  function renderUrlList() {
    urlCount.textContent = urls.length;
    
    if (urls.length === 0) {
      urlList.innerHTML = '<div class="empty-state" id="emptyState">No URLs configured for batch opening<br>Click Add above to add URLs</div>';
      return;
    }

    const listHtml = urls.map((url, index) => `
      <div class="url-item">
        <span class="url-index">${index + 1}</span>
        <span class="url-text">${escapeHtml(url)}</span>
        <button class="button button-destructive"  style="padding: 8px 12px; font-size: 12px;">
          <img src="./icons/url-01.svg">
        </button>
        <button class="button button-destructive delete-btn" data-index="${index}" style="padding: 8px 12px; font-size: 12px;">
          <img src="./icons/url-02.svg">
        </button>
      </div>
    `).join('');
    
    urlList.innerHTML = listHtml;
    
    // 为删除按钮添加事件监听器
    const deleteButtons = urlList.querySelectorAll('.delete-btn');
    deleteButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        const index = parseInt(e.currentTarget.dataset.index);
        removeUrl(index);
      });
    });
  }

  // 移除全局函数，现在使用事件监听器
  // window.removeUrlAt = removeUrl;

  // 显示错误消息
  function showError(message) {
    hideMessages();
    inputError.textContent = message;
    inputError.style.display = 'block';
    setTimeout(hideMessages, 5000);
  }

  // 显示成功消息
  function showSuccess(message) {
    hideMessages();
    inputSuccess.textContent = message;
    inputSuccess.style.display = 'block';
    setTimeout(hideMessages, 3000);
  }

  // 隐藏消息
  function hideMessages() {
    inputError.style.display = 'none';
    inputSuccess.style.display = 'none';
  }

  // HTML 转义
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // 初始化主题管理器
  async function initThemeManager() {
    try {
      themeManager = new ThemeManager();
      
      // 设置当前选中的主题
      themeSelect.value = themeManager.getCurrentTheme();
      
      // 监听主题选择变化
      themeSelect.addEventListener('change', async (e) => {
        await themeManager.setTheme(e.target.value);
        showSuccess('Theme updated successfully');
      });
      
      // 监听来自其他页面的主题变更
      themeManager.onThemeChanged((theme) => {
        themeSelect.value = theme;
      });
      
    } catch (error) {
      console.error('Failed to initialize theme manager:', error);
    }
  }
});